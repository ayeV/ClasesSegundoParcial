#include <stdio.h>
#include <stdlib.h>




int main()
{
    FILE* f;
    int cant;
    int id;

    char marca[50];
    char modelo[50];
    char color[50];
    char idCad[50];
    char anioCad[50];
    int anio;

    f = fopen("autos.csv" ,"r");
    if(f== NULL)
    {
        printf("No se pudo abrir el archivo\n");
        system("pause");
        exit(EXIT_FAILURE);
    }
    while(!feof(f))
    {

        cant =   fscanf(f,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",idCad,marca,modelo,color,anioCad);


        if(cant !=5)
        {
            if(feof(f))
            {
                break;
            }
            else
            {
                printf("Hubo un error leyendo el archivo\n");
                exit(EXIT_FAILURE);
            }
        }
        id = atoi(idCad);
        anio = atoi(anioCad);
       printf("%4d,%20s,%20s,%20s,%4d\n",id,marca,modelo,color,anio);
    }


    fclose(f);
    return 0;
}



