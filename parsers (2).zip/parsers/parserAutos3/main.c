#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char marca[50];
    char modelo[50];
    char color[50];
    int id;
    int anio;
    int estado;


} eAuto;
int main()
{
    FILE* f;
    eAuto* auto1;


    f = fopen("autos.csv","r");
    if(f== NULL)
    {
        printf("No se pudo abrir el archivo\n");
        system("pause");
        exit(EXIT_FAILURE);
    }






    fclose(f);
    return 0;
}

eAuto* new_auto()
{

    eAuto* newAuto;

    newAuto = (eAuto*)malloc(sizeof(eAuto));
    if(newAuto != NULL)
    {
        newAuto->id = 0;
        strcpy(newAuto->marca, "");
        strcpy(newAuto->modelo, "");
        strcpy(newAuto->color, "");
        newAuto->anio = 0;
        newAuto->estado = 0;
    }
    return newAuto;

}



eAuto* new_auto_Param(int id, char* marca, char* modelo,char* color, int anio)
{

    eAuto* newAuto;

    newAuto = new_auto();

    if(newAuto != NULL)
    {
        newAuto->id = id;
        strcpy(newAuto->marca, marca);
        strcpy(newAuto->modelo, modelo);
        strcpy(newAuto->color, color);


        newAuto->anio = anio;
        newAuto->estado = 1;
    }
    return newAuto;

}
int buscarLibre(eAuto* autos, int tam)
{
    int i;
    int indice = -1;
    for( i=0; i<tam; i++)
    {
        if((autos+i)->estado == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}


int parseData(char* fileName,eAuto* autos, int len)
{
    FILE *f;
    int r,i=0;
    char var1[50],var3[50],var2[50],var4[50],var5[50];
    f = fopen(fileName,"r");

    if(f == NULL)
    {
        return -1;
    }
    do
    {
        r = fscanf(f,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5);
        if(r==5)
        {
            autos[i].id = atoi(var1);
            strncpy(autos[i].marca,var2,sizeof(autos[i].marca));
            strncpy(autos[i].modelo,var3,sizeof(autos[i].modelo));
            strncpy(autos[i].color,var4,sizeof(autos[i].color));
            autos[i].anio = atoi(var5);
            i++;
        }
        else
            break;
    }
    while(!feof(f) && i<len);
    fclose(f);
    return i;
}





int agrandarArray(eAuto* array,int* tam){


    int index=0;
    char opc;
    array = (eAuto*)malloc(sizeof(eAuto)*tam);
    do {


        lista[index] = &array;
        index++;
        if(index >= tam)
        {
            tam+=10;
            array = realloc(lista,sizeof(eAuto*)*tam);



        }

        printf("Continuar? ");
        scanf("%c",&opc);
    }
    while(opc!='s');



}
int cargarAutos(eAuto* autos, int tam, char* path)
{

    FILE* f;
    int indice;
    eAuto autoAux;
    int cant;
    int total = 0;

    f = fopen(path, "rb");
    if(f == NULL)
    {
        printf("No se pudo abrir el archivo\n");
        exit(1);
    }



    while(!feof(f))
    {
        indice = buscarLibre(autos, tam);
        if(indice == -1)
        {
            printf("No hay mas lugar\n");
            agrandarArray(autos,tam);
            break;
        }
        else
        {
            cant = fread(&autoAux, sizeof(eAuto), 1, f);

            if(cant != 1)
            {
                if(feof(f))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }

            *(autos+indice) = autoAux;
            total++;


        }
    }
    fclose(f);
    return total;
}
